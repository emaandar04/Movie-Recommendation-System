const axios = require('axios');
const Movie = require('../models/movieModel');

// Render landing page (home with login/register buttons)
exports.showLanding = (req, res) => {
    res.render('home');
};

// Render dashboard (index.ejs)
exports.showHome = (req, res) => {
    res.render('index', {
        error: null,
        fullName: req.session.userName   // <-- pass fullName to index.ejs
    });
};

// Handle recommendations
exports.getRecommendations = async (req, res) => {
    const title = req.body.movieTitle;
    const fullName = req.session.userName;

    if (!title) {
        return res.render('index', {
            error: 'Please enter a movie title',
            fullName
        });
    }

    try {
        const response = await axios.post('http://localhost:5000/recommend', { title });
        const recommendations = response.data.recommendations;

        res.render('recommendations', {
            title,
            recommendations,
            fullName  // pass fullName to recommendations.ejs
        });
    } catch (error) {
        console.error(error.message);
        res.render('index', {
            error: 'Movie not found or AI server error.',
            fullName
        });
    }
};
