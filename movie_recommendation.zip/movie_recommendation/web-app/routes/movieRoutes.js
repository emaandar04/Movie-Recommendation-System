const express = require('express');
const router = express.Router();
const movieController = require('../controllers/movieController');
const isAuthenticated = require('../middleware/isAuthenticated');

router.get('/', movieController.showLanding); // ✅ Home page (login/register)

// Dashboard (index.ejs)
router.get('/dashboard', isAuthenticated, movieController.showHome);

// Recommendations
router.post('/recommend', isAuthenticated, movieController.getRecommendations);

module.exports = router;
